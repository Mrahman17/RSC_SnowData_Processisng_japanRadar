% 
% INPUT PARAMS:
%* datain            -  freq domain data matrix (full, uncropped data)
%* gps_file_path     -  full path to the .txt GPS data file
%* st_vector         -  slow time vectors
%* ft_vector         - fast time range vector
%* c - propogation speed
% ref_chirp_time_dec - time-decimated reference chirp 
% 
% HARD CODED PARAMS:
% gps_file_length   -  length of GPS file name 
% gps file name format ('20181218_220558_ARENA__CTU-CTU-gps.txt')
% gps.utc_time format 
% 
%* -- needed for elevation compensation
% 

function[data_elev_comp] = elev_comp_Japan(data_in, gps_path, st_vector, ft_vector c, ref_chirp_time_dec)

%% Part 1 - load and parse GPS data
% assume GPS filename's length is always 38 (including .txt)
gps_file_length = 38; 
gps_file = gps_path(end-gps_file_length+1:end); 
L=length(gps_file);
% date
date0 = gps_file(end-L+1:8);
date1 = [gps_file(end-L+1:4) '-' gps_file(end-L+5:6) '-' gps_file(end-L+7:8)] ;
% load gps data
display(' Parsing GPS data ...')
gps = parse_gps_data(gps_path);
display(' Finished parsing')
gps_utc_time_tmp = gps.utc_time; 
% epoch time vectors
for ii = 1 : length(gps.utc_time)
    gps_utc_time_str = num2str(gps_utc_time_tmp(ii));
    gps_utc_time_str = ['0' gps_utc_time_str(1:end)];
    % update the utc_time_str to standard form 
    gps_time_stamp = [date1 ' ' gps_utc_time_str(1:2) ':' gps_utc_time_str(3:4) ':' gps_utc_time_str(5:6)];
    gps_epoch_time(ii) = posixtime(datetime(gps_time_stamp));
end

%% elevation compensation
data_elev_comp = data_in; 
% gps record starts after data record 
st_tmp = st_vector;
idx0 = min(find(st_vector >= gps_epoch_time(1)));   
% crop in slow time
data   = datain(:, idx0:end);
st_tmp = st_tmp(idx0:end); 
% crop in fast time 
idx1 = min(find(gps_epoch_time>=st_tmp(1))); 
idx2 = min(find(gps_epoch_time>=st_tmp(end))); 
gps_epoch_time_gated = gps_epoch_time(idx1:idx2);
% offset index - disabled
%if there is any offset in hardware,we have to replace this 0 with that
%offset value
gps_offset_idx = 0*round(1/(gps.gps_time(2)-gps.gps_time(1)));
%interpolate
elev = interp1(gps.gps_time(idx1-gps_offset_idx:idx2-gps_offset_idx),...
    gps.elev(idx1-1*gps_offset_idx:idx2-1*gps_offset_idx),radar_gps_time,'linear','extrap');
% shift data in fast time
shift_direction=1;  % MUST BE +1 OR -1! --  changes whether data is shifted up or down
dt = ft_vector(2) - ft_vector(1);
for ii=1:size(datain,2)
    shift_elev_idx(ii)   = round(1*(1/dt)*(elev(ii)-elev(1))/3e8);
    data_elev_comp(:,ii) = circshift(data_elev_comp(:,ii),shift_direction*shift_elev_idx(ii));
end

%% Latitude, longitude, range/distance
% % crop in fast time 
% gps_lat              = gps.latitude(idx1:idx2); 
% gps_long             = gps.longitude(idx1:idx2); 
% % interpolate latitude, longitude
% lat = interp1(gps_epoch_time_gated, gps_lat, ...
%     linspace(gps_epoch_time_gated(1), max(gps_epoch_time_gated), length(st_tmp)));
% lon = interp1(gps_epoch_time_gated, gps_lon, ...
%     linspace(gps_epoch_time_gated(1), max(gps_epoch_time_gated), length(st_tmp)));

% % distance/range vector
% dist(1) = 0; 
% for ii=1:length(lat)-1
%     dist(ii+1) = dist(ii) + sw_dist([lat(ii) lat(ii+1)], [lon(ii) lon(ii+1)], 'km'); 
% end

% % surface time
% [c, idx] = max(20*log10(abs(data(:, 1))))
% surf_time = ref_chirp_time_dec(idx);
% % range vector
%     var1=3.15; %update this, current from greenland code
% range = (ft_vector - surf_time) .* c ./ sqrt(var1) ./ 2;
