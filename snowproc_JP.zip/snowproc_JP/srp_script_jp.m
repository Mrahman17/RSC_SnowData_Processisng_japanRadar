% top level code to run snow radar processor script

clear all;

path(path,'C:\SEVGI_LAPTOP_TEKNIK\RESEARCH\RSC\SNOW_RADAR_PROCESSOR\one_timestamp\')
first_file = 'one_timestamp\20181217_061242_0000.mat';

fnum=33;       
IntN=5;        
adc_sampFreq=1200*10^6;
dac_sampFreq=2400e6;
NumPoints=60000;
pulse_width=dac_sampFreq/NumPoints;
dec=4*2;
Fs=adc_sampFreq/dec;

[data_image]=snowradarp(fnum,first_file,IntN,adc_sampFreq,dec);

%% GPS processing and Elevation compesation

% fast and slow time vectors. 
[row,col]=size(data_image);
ft_vector=(0:1:row)*(1/Fs);          % Fast time vector
st_vector=(0:1:col)*pulse_width      % Slow time Vector


%verify gps filename format
gps_path = 'J:\Japan Antarctica data\UA_radar\bak_Japan_data_GPS_log__renamed\Log_files\20181219\20181218_061242_ARENA__CTU-CTU-gps.txt';
c=3e8;
data_elev_comp = elev_comp_Japan(data_image, gps_path, st_vector, ft_vector, c, '');

disp('Generating elevation compensated echogram...')
L = length(data_elev_comp(:,1));
data_norm = 10*log10(abs(data_elev_comp(1:floor(L/2),:)));

% check if the indexing for data_norm needs to be changed in the second
% term
for ii=1:size(data_norm,2)
    data_norm(:,ii) = data_norm(:,ii) - max(data_norm(1:600,ii));
end

freq = (Fs/2)*linspace(0,1,size(data_elev_comp,1)/2);
figure; 
imagesc([], freq/1e6, data_norm);
title('Echogram using both modes (concatenate data for a total 2-18 GHz)');
colormap(1-gray);
ylabel('Beat frequency (MHz)');
xlabel('Slow time index');