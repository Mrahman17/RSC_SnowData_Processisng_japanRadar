%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% SNOW RADAR PROCESSOR                                   %%%%%%%%
%%%%%%%% VERSION 1.0                                            %%%%%%%% 
%%%%%%%% Last Edited:  3/12/19                                  %%%%%%%%
%%%%%%%% By: S.Z. Gurbuz                                        %%%%%%%%  
%%%%%%%%                                                        %%%%%%%%
%%%%%%%% INPUTS                                                 %%%%%%%%  
%%%%%%%% num_files:  number of files                            %%%%%%%%
%%%%%%%% first_filename: filename of first file, e.g. "xyz.mat" %%%%%%%%
%%%%%%%%      (function takes as input decompressed .mat files) %%%%%%%%
%%%%%%%% IntN: number of times hardware integration (hN) should %%%%%%%%  
%%%%%%%%       be repeated, e.g. IntN x hN = total integration  %%%%%%%%     
%%%%%%%%                                                        %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [data_image]=snowradarp(num_files,first_filename,IntN,adc_sampFreq,dec)

% Create wait bar.
wait_bar = waitbar(0, 'Reading in data files...');

% Loop through all target files and stitch their matrices together.
filename = first_filename;
final_data = [];
for ii=0:num_files-1    
    % Load *.mat file and extract data matrix.
    load(filename);
    subset = Long_Chirp_Profiles;
    
    % Stitch matrices.
    final_data = [final_data subset];
    
        % Update wait bar.
    waitbar((ii+1)/num_files);

end;

% Save concatenated chirp data
%    concat_filename = num2str([char(first_filename(end-23:end-9)) '_concat.mat'])
%    save(concat_filename,'final_data');
% final_data too large to be saved; need mat-fie version 7.3 or later

% Close wait bar.
close(wait_bar);

% 
% Process the data
% 

% Convert data type.
old_data = double(final_data);
figure(1); title('Old Sample Chirp'); plot(real(old_data(:,1)));

% Slice off unwanted regions
d=abs(old_data(:,1));
I=find(abs(diff(d))>mean(d)/2);
lowlim=min(I)
for ii=1:size(old_data,2),
    new_data(:,ii)=old_data(lowlim:end,ii);
end;
L = length(new_data(:,1))
figure(2); title('New Sample Chirp'); plot(real(new_data(:,1)));

% Perform coherent average over 1000 samples (200 presums, so 5 more).
hN = 200;  % Should be read from config file
message = ['Coherent integration of ' num2str(IntN) ' times ' num2str(hN) ' pulses...'];
h = waitbar(0, message);
for ii = 1:size(new_data,2)
    if ii > 5 && ii < (size(new_data,2) - IntN)
        avg_data(:,ii) = mean(new_data(:,ii-IntN:ii+IntN),2);
    else
        avg_data(:,ii) = new_data(:,ii);
    end
    waitbar(ii/size(new_data,2));
end
close(h);


% Set up a hanning window and perform the FFT.
h = waitbar(0, 'Performing FFT...');
hann_window = hanning(L);
for ii=1:size(new_data,2)
    data_image(:,ii) = fft(avg_data(:,ii).*hann_window);
    waitbar(ii/size(avg_data,2));
end
close(h);

% Examine power spectrum of one sample chirp
Fs=adc_sampFreq/dec;                      
xdft = data_image(:,1);                     % get one chirp
xdft = xdft(1:L/2+1);                       % get half the chirp
psdx = (1/(Fs*L)) * abs(xdft).^2;           % compute power spectrum
psdx(2:end-1) = 2*psdx(2:end-1);
freq = 0:Fs/L:Fs/2;
dist=(freq*3e8)/16e13                             % Converting Freq into distance
figure(3); plot(10*log10(psdx));
figure(4); plot(freq/(10^6),10*log10(psdx));
figure(5); plot(dist,10*log10(psdx));
grid on;
title('Periodogram Using FFT');
xlabel('Frequency (MHz)');


% Create echogram from results.
h = waitbar(0, 'Creating echogram...');
freq = Fs*linspace(0,1,size(avg_data,1)/2);
freq = freq/1e6;
data_norm = 10*log10(abs(data_image(1:floor(L/2),:)));
for ii=1:size(data_norm,2)
    data_norm(:,ii) = data_norm(:,ii) - max(data_norm(1:600,ii));
    waitbar(ii/size(avg_data,2));
end
close(h);

% Display figure.
figure(5); imagesc([], freq/1e6, data_norm);
colormap(1-gray);
ylabel('Beat frequency (MHz)');
xlabel('Slot time index');

end     % end of function
