% Generate parameter list .mat file for VHF processing

% Specify mode
mode = 0;   % long mode is 0, short mode is 3

% Specify Radar parameters
radar_param.fs=1e9/2;   % adc sampling frequency
radar_param.BW=-300e6;    % Bandwidth
radar_param.f0=900e6;   % starting frequency
radar_param.Fs=2000e6;  % DAC (Tx) sampling frequency
radar_param.tp=10e-6;   % Pulse Duration
radar_param.fnco=750e6; % nco mixer freq.
radar_param.dec =4;     % Decimation
radar_param.fc  =750e6; % Center Frequency
radar_param.coh_avg= 0;  % coherent average length

% Parameters for 2019 Data
radar_param.pri = 100*10^(-6);  % pulse repetition interval
radar_param.hInt = 256;  % integration in hardware
radar_param.v_avg = 1.38;  % average platform velocity (5 km/hr = 1.38 m/s)


% Specify SAR parameters
sar_param.eps2= 3.15;      % Dielectric constant of the medium you are imaging
sar_param.max_depth =2800; % Depth of bottom layer in terms of meters
sar_param.delAz= radar_param.pri*radar_param.hInt*radar_param.v_avg;        % Azimuth spatial sampling
sar_param.h    = 0;        % Distance of the Platform from the surface
sar_param.beamwidth= 1.3*pi/180; 
                           % Antenna Beamwidth in radian


% Save workspace parameters
save uhf_params.mat

                           
                           