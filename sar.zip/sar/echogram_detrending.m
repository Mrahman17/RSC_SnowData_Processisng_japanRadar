%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                        Detrending the SAR Echogram                  %%%
%%%                                                                     %%%
%%%                                                                     %%%    
%%%                           M. Mahbubur Rahman                        %%%
%%%                                                                     %%%
%%%                          The University of Alabama                  %%%
%%%                           Remote Sensing Center                     %%% 
%%%                               Date: 6/28/19                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% this function divides the echogram into two parts (600m to 1500 and 1500m to 3300m )
% ... to ensure each part has a dynamic ragne of 20dB
%Inputs: 
% multi_ch_data= combined sar processed data from all the channels
% range: range axis
% St_idx: slow-time index corresponds to spectecualr range line (you can use any
% slow time index though). 
%Outputs:
% dtrnd_echo: echogram after detrending echogram
% dtrn_range: truncated range axis as we are plotting from 600m to 3600m

function [dtrnd_echo,dtrn_range] = echogram_detrending(multi_ch_data,range,st_idx)
        
        % Dtrend
        
        % For 600m to 1500m .....
        % get the corresponding ft indices
        
        del_r=range(2)-range(1);
        
        R1_idx=min(find(range < 600+2*del_r & range >600 ));
        R2_idx=min(find(range < 1500+2*del_r & range >1500 ));
        R3_idx=min(find(range < 3600+2*del_r & range >3600 ));
        
        x1=20*log10(abs(multi_ch_data(R1_idx:R2_idx,:)));
        
        %dtrnd_rng_idx=(11939:19710);
        x_dtr=20*log10(abs(multi_ch_data(R2_idx+1:R3_idx,:)));
        x_mean=mean(20*log10(abs(multi_ch_data(R2_idx+1:R3_idx,st_idx))));
        
        % find those samples which exceed 20 dB above the average power and multiply
        % them with a small number to bring it within 20 dB of avg power
        for mm=1:size(x_dtr,2)
                for ii=1:size(x_dtr,1)
                        
                        if x_dtr(ii,mm)>(x_mean+20)
                                m_factor=(x_mean+20)/x_dtr(ii,mm);
                                
                                x_dtr(ii,mm)=(x_dtr(ii,mm))*m_factor;
                                clear m_factor;
                        else
                                x_dtr(ii,mm)=x_dtr(ii,mm);
                        end
                end
        end
        
        
        
%         figure(988); subplot(211);
%         imagesc([],range(6000:8980),xn(1:2981,:));
%         colormap(1-gray);ylabel('Range (m)');
%         subplot(212);
%         imagesc([],range(8981:19710),xn(2982:end,:));
%         colormap(1-gray);ylabel('Range (m)')
%         sgtitle('Echogram after Detrending')
        
        echo1=imagesc([],range(R1_idx:R2_idx),x1);
        II=getimage(echo1);
        echo2= imagesc([],range(R2_idx +1:R3_idx),x_dtr);
        
        II2=getimage(echo2);
        dtrnd_echo=vertcat(II,II2);
        dtrn_range=range(R1_idx:R3_idx);
%         figure(420); imagesc([],range(6000:19710),dtrnd_echo); colormap(1-gray)
%         ylabel('range (m)');title('Echogram after Detrending')

clear II;
clear II2;
 
end

