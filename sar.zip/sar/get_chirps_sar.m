function matrix = get_chirps_sar(filename, mode,radar_param)
    contents = load(string(filename));
    matrix = contents.Results(mode + 1).Chirps;
    %matrix=coh_avg_dec(matrix1,radar_param.coh_avg);
end
