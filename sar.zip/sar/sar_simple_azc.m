function sar_data=sar_simple_azc(datain,st,ft_vector,dist,er,sar_res,vplat,aa)

    st_vector=st-st(1);
    lambda=3e8/200e6/sqrt(er);
    
    R0=ft_vector*3e8/2/sqrt(er);
    
    %dx=(dist(2)-dist(1))*1000;
    dx=(dist(2)-dist(1));
   
    nfft=size(datain,2);
    %nfft=2^nextpow2(nfft);
   
    clear sar_data
    parfor_progress(size(datain,1));

    parfor rg=1:size(datain,1)
  
        
        %round(rg/size(datain,1)*100)
        
        Lsar=lambda*R0(rg)/2/sar_res;
        Lsar_idx=round(Lsar/dx);
      
        az_chirp_tmp = exp(-1i*2*pi.*((vplat^2.*(aa*st_vector(1:Lsar_idx)).^2)/ (lambda.*R0(rg))));

        sar_data(rg,:) = ifft(conj(fft(az_chirp_tmp,nfft)).* fft(datain(rg,:),nfft));
        parfor_progress;
    end
    parfor_progress(0);
    


%     clear sar_data
%     sar_data=zeros(size(datain));
%     %parfor_progress(size(datain,1));
%     for rg=1:size(datain,1)
%         (rg/size(datain,1)*100)
%        % (rg/240*100)
%         
%         Lsar=lambda*R0(rg)/2/sar_res;
%         Lsar_idx=round(Lsar/dx);
%         az_chirp_tmp = exp(1i*2*pi.*((vplat^2.*(aa*st_vector(1:Lsar_idx)).^2)/ (lambda.*R0(rg))));
%        % Lsar
%        
%        %Lsar_idx
%         for jj=1300:size(datain,2)-1300
%             
%             data_apt=datain(rg,jj-round(Lsar_idx/2):jj+round(Lsar_idx/2));
%             
%             nfft=length(data_apt);
%             
%             sar_data(rg,jj-round(Lsar_idx/2):jj+round(Lsar_idx/2)) = ifft(conj(fft(az_chirp_tmp,nfft)).* fft(data_apt,nfft))     ;
%         end       
%         
%         %parfor_progress;
%     end
%     %parfor_progress(0);
    
    
    
    %sar_data=0;
    
    
end
