%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Read PPS counters and concatenate matrices from files  %%
%                      Jack O'Donohue                      %%
%                                                          %%
%      Reads a sequence of files of the form               %%
%  [directory][file_prefix]_Channel[channel]_[number].mat  %%
%  Parameters are substituted into the file name as they   %%
%  above, and if number is natural number in the interval  %%
%  [first_file_number, first_file_number + num_files - 1], %%
%  the file is read. Chirps contains the concatenated      %%
% matrices, and counters contains the PPS counters in the  %%
%   file.                                                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  Inputs example
% first_file_number=10;
% num_files=5;
% directory= '/mnt/HDD03/Greenland2018/raw_files/yolo/';
% file_prefix= '20180820_073902';
% channel= 0
%% Outputs
% chirps: Concatenated Data matrix
% counters: concatenated PPS_coutners
%%


function [chirps, counters] = load_chirps_and_counters_sar(first_file_number, num_files, directory, file_prefix, channel, mode,radar_param)
    % We need this because to get the number of rows, we assume that there is at least one file
    if num_files == 0
        chirps = [];
        counters = [];
        return;
    end

    [matrix_files, counter_files] = make_file_list(first_file_number, num_files, directory, file_prefix, channel);
    counters = get_pps_counters(counter_files, mode,radar_param);

    % read files in parallel before preallocation
    unconcatenated = cell(num_files);

    for i = 1:num_files
        unconcatenated{i} = get_chirps_sar(matrix_files(i), mode,radar_param);
    end

    % preallocate concatenated matrix
    last_index = 1;
    chirps = zeros(size(unconcatenated{1}, 1), size(counters, 1));

    for i = 1:num_files
        chirps(:,last_index:last_index + size(unconcatenated{i}, 2) - 1) = unconcatenated{i};
        last_index = last_index + size(unconcatenated{i}, 2);
    end
end
