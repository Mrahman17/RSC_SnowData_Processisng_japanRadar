% Given a list of counter files, and a column index, this function
% determines which counter file in the range of files contains the column.
% If the column is out of range, [-1, -1] is returned.
function [file_index, column_offset] = column_to_file(counter_file_list, column_index, mode)
    last_index = 0;

    if column_index <= 0
        file_index = -1;
        column_offset = -1;
        return
    end

    for i = 1:size(counter_file_list, 1 )
        current = load(string(counter_file_list{i}));
        length = size(current.Counters(mode + 1).PPS_Counters, 2);

        if column_index <= last_index + length
            file_index = i;
            column_offset = last_index + 1;
            return;
        end

        last_index = last_index + length;
    end

    file_index = -1;
    column_offset = -1;
end
