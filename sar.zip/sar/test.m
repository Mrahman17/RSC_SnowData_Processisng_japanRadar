
load('/media/radarops/c00/UHF_data/20180815_062742_Channel0_0027.mat');
data=Results(1).Chirps;
mode=0;   % it's the long mode/short mode 
channel=0;

% Specify Radar Parameters
radar_param.fs=1e9/2;    % ADC sampling frequency
radar_param.BW=-300e6;     % Bandwidth
radar_param.f0=900e6;    % starting frequency
radar_param.Fs=2000e6;   % DAC (Tx) sampling frequency
radar_param.tp=10e-6;    % Pulse Duration
radar_param.fnco=750e6;  % nco mixer freq.
radar_param.dec =4;      % Decimation
radar_param.fc  =750e6;  % Center Frequency
radar_param.coh_avg= 8;  % coherent average length,put a 0 if you don't performs coh_avg
radar_param.Incoh_avg= 5;% Incoherent average length,put a 0 if you don't performs Incoh_avg
% =========================================================================

% Find fast-time vector
[M1,N1]= size(data);
fs=radar_param.fs;
dt=1/fs; %due to complex sampling; sampling at 500 MHz I/Q
ft=0:dt:(M1-1)*dt;

% debugging plots, comment out later
freq=[-radar_param.fs/2 : radar_param.fs/(22008) : radar_param.fs/2 - radar_param.fs/(2*22008)];
figure(1); plot(freq/1e6,20*log10(abs(fftshift(fft(data(:,300))))));

% Pulse Compression
radar_param.T=max(ft);

dec=radar_param.dec;


[ref_chirp,ref_chirp_time]=chirp_gen_v7(radar_param,0e-6,4);
[ref_chirp_dec,ref_chirp_time_dec]=DDC(ref_chirp,radar_param.fnco,ref_chirp_time,dec);
% figure; plot(ref_chirp);
% figure; plot(f,20*log10(abs(fftshift(fft(ref_chirp_dec)))));title('reference chirp'); grid on;


N = radar_param.Fs*radar_param.tp;   % number of samples in pulse duration
x=( [fliplr(ref_chirp_dec(1:N/4))  zeros(1,M1-1)]);   % zeropad reference chirp
ref_chirp_dec_fft = conj(fft((x)));



datain=zeros((M1+N/4)-1,N1);
datain(1:M1,:)=data;


parfor ii=1:size(datain,2)
        temp(:,ii)=ifft(fft(datain(:,ii)).'.*ref_chirp_dec_fft);
end

data_pc=temp(1:M1,:); %Throw out Zero-padded samples
size(data_pc)

figure(2); plot(freq/1e6,20*log10(abs(fftshift(fft(data_pc(:,300))))));
