% =========================================================================
% This pulse compression function will work only for UHF data
% Inputs:1) data= provide raw data after coherent integration
%        2) radar_param: This struct variable should contain following
%        parameters
%           radar_param.fs=1e9/2;   % adc sampling frequency
%           radar_param.BW=300e6;    % Bandwidth
%           radar_param.f0=600e6;   % starting frequency
%           radar_param.Fs=2000e6;  % DAC (Tx) sampling frequency
%           radar_param.tp=10e-6;   % Pulse Duration
%           radar_param.fnco=750e6; % nco mixer freq.
%           radar_param.dec =4;     % Decimation
%           radar_param.fc  =750e6; % Center Frequency
%           radar_param.data_fnco=250e6;% this will be used only for filtering the data correctly
%                                       % Notice the value, it's not 750 MHz
% Output: This function returns pulse compressed data in Freqeuncy domain...
%         the output matrix fast time dimension increses due to zero padding, so
%         get rid of zero padded samples once you get back in time domain. 
% Written by: Mahbub, RSC, UA
% Version: V1a
% =========================================================================


function data_tmp_pc=PComp_uhf(data,radar_param)
        
        % set the axis
        fs=radar_param.fs;
        dt=1/fs;
        n=size(data,1);
        ft = 0:dt:((n-1)*dt); % time vector
        f = (0:n-1)*(fs/n);  %frequency range
        f1=((-n/2:n/2-1)/n)*fs; % zero-centred frequency axis
        
        % filtering the data
        f0= radar_param.f0; % 600 MHz
        f1= f0+radar_param.BW; % 900 MHz
        
        % with 500MHz ADC sampling freq., f0=600-500 =100
        % and f1=900-500=400 MHz
        % Now, due to 250 MHz data mixing freq. (data_fnco=250e6),f0 will be
        % -150 MHz and f1 will be +150 MHz.
        % We will design a lowpass fir filter with cutt-off freq. of 150 MHz...
        % with a sampling rate of 500 MHz
        % the filter will be applied on both I & Q data
        
       if f0> fs
               f0_tmp= f0-fs;
               f1_tmp= f1-fs;
               
               data_fnco= radar_param.data_fnco;
               
               f0_new=f0_tmp- data_fnco;
               f1_new=f1_tmp -data_fnco;
               
              if f0_new <= 0 && (abs(f0_new)==f1_new)
                      filt_type= 'lowpassfir';
                      cutoff_freq= f1_new;
              end
       else
              
               disp('This function requires radar_param from UHF radar');
               return;
       end
               
       
       % get the I & Q data
       dataI=real(data);
       dataq=imag(data);
        
       % Design a Low pass filter
       stop_freq= cutoff_freq +5e6;
        lof = designfilt(filt_type, 'PassbandFrequency', cutoff_freq, ...
                 'StopbandFrequency', stop_freq, ...
                 'PassbandRipple', 0.25, 'StopbandAttenuation', 45, ...
                 'SampleRate', fs);
         
        % Apply the filter on I & Q Data
         dataI_filt=filtfilt(lof,dataI);
         dataq_filt=filtfilt(lof,dataq);
         datacomplex=dataI_filt+1j*dataq_filt;
         
%          figure(20); plot(20*log10(abs(fftshift(fft(datacomplex(:,100)))))); title('IQ-Data after Filtering');
%          grid on;xlabel('Range Samples');
%          
         %%this plot will help to find the window length
         %%uncomment the figure (20)and plot the filtered IQ spectrum.
         %%find the range sampels range where signal is persent,
         
         % we have to apply window in freqeuncy domain
         fft_data_complex=fftshift(fft(datacomplex));
         N=17820-4196; %Indexes for (f0_new) -150 MHz to (f1_new) +150 MHz
         hanwin=hanning(N);
         data_weight=fft_data_complex(4196:17819,:).*hanwin;
         
         data_orgnl=[fft_data_complex(1:4195,:); data_weight; fft_data_complex(17820:end,:)];
         
         % get back to time domain
         data_n=ifft(data_orgnl);
         [M1,N1]=size(data_n);
         
         ref_chirp_signal=chirpsignal_uhf( radar_param, cutoff_freq, filt_type); % get the chirp signal
         
         N=length(ref_chirp_signal);
        
         x=( [ref_chirp_signal.'  zeros(1,M1-1)]);   % zeropad reference chirp
         ref_chirp_fft = conj(fft(x));
         
         datain=zeros((M1+N)-1,N1);
         datain(1:M1,:)=data_n;
         
         parfor ii=1:size(datain,2)
                 data_tmp_pc(:,ii)=(fft(datain(:,ii)).'.*ref_chirp_fft);
         end
         
         
     
end