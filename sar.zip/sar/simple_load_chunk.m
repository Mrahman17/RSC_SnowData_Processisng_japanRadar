function chunk = simple_load_chunk(matrix_file_list, counter_file_list, first_col_index, last_col_index, mode)
    [first_file_index, offset] = column_to_file(counter_file_list, first_col_index, mode);
    [last_file_index, ~] = column_to_file(counter_file_list, last_col_index, mode);
    
    
    concatenated_files = load_concatenated_files(matrix_file_list, counter_file_list, first_file_index, last_file_index, mode);
    first_col_index = first_col_index - offset;
    last_col_index = last_col_index - offset;
    
    chunk = concatenated_files(:, first_col_index:last_col_index);
end