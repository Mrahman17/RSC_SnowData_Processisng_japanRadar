function [matrix_files, counter_files, gps_file] = read_job(filename)
    fid = fopen(filename);
    
    gps_file = fgetl(fid);
    
    matrix_files = {};
    counter_files = {};
    
    while ~feof(fid)
        line = fgetl(fid);
        left_expression = '(?<={'')[^,]*(?='')';
        right_expression = '(?<='')[^,]*(?=''})';
        
        matrix_files = [matrix_files; regexp(line, left_expression, 'match')];
        counter_files = [counter_files; regexp(line, right_expression, 'match')];
    end
    
    fclose(fid);
end