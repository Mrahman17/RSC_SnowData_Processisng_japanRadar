#/bin/bash

function invoke_sar() {
    ./InvokeSAR.sh "$@" -d
}

function get_projection() {
    
}

function get_regular_expression() {

}

function intialize_defaults() {
    
}

file=$1
idx=0



lines=$(cat $1 | wc -l)

exit

lock=$(mktemp)
exec 3>$lock

function increment_idx() {
    retIdx=$idx
    idx=$((idx+1))
    echo read $idx
   
    return $retIdx
}

set -e
function free_lock() {
    rm $lock
}

trap free_lock EXIT

function next_process() {
    increment_idx
    id=$?

    while [ $id -lt $lines ]; do
        id=$((id+1))
        echo next $i

        arguments=$(awk -v line=$id 'NR==line' $file)
        invoke_sar $arguments

        increment_idx
        id=$?
    done
}

trap next_proccess CHLD

if [[ ! -f $file ]]; then
    &>2 echo "Error: joblist file $file not found"
    exit 1
fi

for i in $(seq 1 $2); do
    echo spawning $i
    next_process &
done

exit 0

