function [data_out]=incoh_avg_dec(data_in,avg_length)
avg=avg_length;
if avg==0
    data_out=data_in;
else
    aa=1;
    [m,n]=size(data_in);
    for ii=1:avg:n
        display(['Incoherent integration: ' num2str(ii) '/' num2str(n)])

        if ii>avg && ii<n-avg
            data_out(:,aa)=mean(abs(data_in(:,ii-avg:ii+avg)),2);
        else
            data_out(:,aa)=data_in(:,ii);
        end
        aa=aa+1;
    end
end