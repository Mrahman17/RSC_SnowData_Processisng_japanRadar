%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                     FK MIGRATION ACROSS TWO-LAYERS                  %%%
%%%                            LAYER 1 : AIR                            %%% 
%%%                         LAYER 2:  ICE OR SNOW                       %%% 
%%%                      METHOD:  STOLT INTERPOLATION                   %%%
%%%  REFERENCE:                                                         %%%
%%%  M. H. Skjelvareid, T. Olofsson, Y. Birkelund and Y. Larsen,        %%%
%%%  "Synthetic aperture focusing of ultrasonic data from multilayered  %%%
%%%  media using an omega-K algorithm," in IEEE Transactions on         %%%  
%%%  Ultrasonics, Ferroelectrics, and Frequency Control, 58 (5),        %%% 
%%%  pp. 1037-1048, May 2011.                                           %%%
%%%                                                                     %%%
%%%                             Sevgi Z. Gurbuz                         %%%
%%%                            Md. Mahbubur Rahman                      %%%
%%%                          The University of Alabama                  %%%
%%%                           Remote Sensing Center                     %%% 
%%%                               Date: 6/22/19                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [sardata] = rma2L_with_KF(sigData,numPulses,delAz,fs,fc,npts,eps2,elev,beamwidth,dmax)

% Input parameters
% sigData : frequency vs. slow-time data matrix after pulse compression
% numPulses : number of slow-time pulses in synthetic aperture
% delAz : spatial resolution in azimuth
% fs : sampling frequency in fast-time
% fc : center frequency
% npts: total number of fast-time samples
% eps2:  diaelectric constant of 2nd layer (snow or ice)
% elev:  elevation of platform above layer interface 
% beamwidth = real antenna beamwidth
% dmax = maximum depth

% Perform an azimuth FFT on the range compressed signal.
% sdata is now in f-k domain
sdata =fftshift(fft(sigData,[],2),2);
clear sigData;
% Kfilter to account for refraction and beamwidth effects
% In the air:
Lmin=elev*tan(0.5*beamwidth);              % Minimum half-aperture length
% In the ice:
% Ice refraction index
eta_ice = sqrt(eps2);
% Velocity in ice
c=3e8;
c_ice = c/eta_ice;
beamwidth_ice=2*asin(sin(0.5*beamwidth)/eta_ice);
Lmax=Lmin+dmax*tan(0.5*beamwidth_ice);   % Maximum half-aperture length


% Compute azimuth wavenumber
kaz = pi/delAz*linspace(-1,1-1/numPulses,numPulses);
kazimuth = kaz.';

%2.4)Refraction and antenna beam width effects
% Define frequency vector in fast-time (depth direction)
fastTime = [0:1/fs:(npts-1)/fs];
ts = 1/fs;
interface = floor(2*elev/(c*ts));   % number of fast time samples in air;
dz_ice = c_ice*ts/2;
R = [interface:npts-1]*dz_ice; % range vector with distance in air subtracted
Lm=Lmin+R*tan(0.5*beamwidth_ice); %maximum half-beamwidth at each depth
Kfilter=zeros(npts,numPulses);
c = 3*10^8;  % speed of light in air
frequencyRange = linspace(fc-fs/2,fc+fs/2,length(fastTime));
% frequencyRange = linspace(fc-fs/2,fc+fs/2,length(fastTime));
k_air = 2*pi*frequencyRange / c;
Kfilter(find(abs(asin(1./(2*k_air.')*kaz))<=beamwidth))=1;

irow=size(Kfilter,1);
idones=find(Kfilter(irow,:));
iL=min(idones);
iR=max(idones);
Kfilter(irow,idones)=Kfilter(irow,idones).*hann(iR-iL+1).';
Kfilter(:,idones)=repmat(Kfilter(irow,idones),[npts,1]);

kfdata=sdata.*Kfilter; 
display('Done with kfiltering')

clear sdata;
% Compute migration through the air
kr_air = 2*(2*pi*frequencyRange)/c;
kz_air = kr_air.^2-kazimuth.^2;
kz_air = sqrt(kz_air.*(kz_air>0));

% Apply range migration through air
fsmPol0 = kfdata.'.*exp(1i*kz_air*elev);
clear kfdata;
% Compute migration through the ice
kr_ice = 2*(2*pi*frequencyRange)/c_ice;
kz_ice = kr_ice.^2-kazimuth.^2;
kz_ice = sqrt(kz_ice.*(kz_ice>0));

%Perform Stolt Interpolation 
stoltPol = fsmPol0;
for i = 1:size((fsmPol0),1)
    stoltPol(i,:) = abs(kz_ice(i,:)).^2./kr_ice.*interp_vec(kz_ice(i,:),fsmPol0(i,:),kr_ice(1,:));
end
stoltPol(isnan(stoltPol)) = 1e-30;
clear fsmPol0;
sardata = ifft2(fftshift( fftshift(stoltPol,1),2) );