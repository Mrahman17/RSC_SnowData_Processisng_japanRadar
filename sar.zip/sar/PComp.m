%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%               PULSE COMPRESSION WITH DECIMATION OPTION              %%%
%%%                                                                     %%%
%%%                             Sevgi Z. Gurbuz                         %%%    
%%%                           Md. Mahbubur Rahman                       %%%
%%%                          The University of Alabama                  %%%
%%%                           Remote Sensing Center                     %%% 
%%%                               Date: 6/22/19                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [data_pc,surf_time] = PComp(data,radar_param,dopt,dec,mode)

% Input Parameters
% Data :  Fast-time, Slow-time input matrix
% radar_param is a structure that contains the key system parameters
% radar_param.fs : sampling frequency (according to DAC, thus xmit pulse)
% radar_param.BW : bandwidth
% radar_param.f0 : minimum frequency in chirp
% radar_param.tp : pulse duration
% radar_param.T : pulse repetition interval
% radar_param.fnco : center frequency of downconversion nco
% dopt indicates whether decimation will be done or not (1=yes, else no)
% dec indicates decimation factor
% mode determines whether result is return in time-domain or freq-domain
%    mode = 1 (time-domain), else frequency-domain, 
%if data return in Frequency domain, then zeropadded extra samples should be
%thrown out once data are converted into time domain.
%    domain

[M1,N1]= size(data);

% dt=1/radar_param.fs; 
% ft=0:dt:(M1-1)*dt;

% Generate reference chirp
[ref_chirp,ref_chirp_time]=chirp_gen_v7(radar_param,0e-6,1);
if dopt == 1,
    [ref_chirp_dec,ref_chirp_time_dec]=DDC(ref_chirp,radar_param.fnco,ref_chirp_time,dec);
else
    ref_chirp_dec = ref_chirp;
    ref_chirp_time_dec = ref_chirp_time;
end;  % endif

N = radar_param.Fs*radar_param.tp;   % number of samples in pulse duration
x=( [ref_chirp_dec(1:N/4)  zeros(1,M1-1)]);   % zeropad reference chirp
ref_chirp_dec_fft = conj(fft(x));

datain=zeros((M1+N/4)-1,N1);
datain(1:M1,:)=data;

if mode == 1,    % return result in time-domain
    parfor ii=1:size(datain,2),
      temp(:,ii)=ifft(fft(datain(:,ii)).'.*ref_chirp_dec_fft);
    end;   % endfor
    data_pc=temp(1:M1,:); %Throw out Zero-padded samples
    size(data_pc)
   % find surface time
   [~,idx]=max(20*log10(abs(data_pc(:,1))));
   surf_time=ref_chirp_time_dec(idx);
   
else            % return result in frequency-domain
     parfor ii=1:size(datain,2),
      data_pc(:,ii)=fft(datain(:,ii)).'.*ref_chirp_dec_fft;
    end;   % endfor
    surf_time= 0.212e-6;
end;  % endif