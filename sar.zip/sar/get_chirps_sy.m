function matrix = get_chirps(filename, mode,radar_param)
    contents = load(string(filename));
    matrix1 = contents.Results(mode + 1).Chirps;
    matrix=coh_avg_dec(matrix1,radar_param.coh_avg_dec);
    matrix=coh_avg(matrix,radar_param.coh_avg);

end
