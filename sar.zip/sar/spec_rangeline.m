
%this Function search for spectecular range line in SAR processed data
% Input: SAR Proc. data
%        idx1: staring range value index  
%        idx2: ending range value  index
% output: 1.index-> spectecular slow-time index
%         2.ft_idx-> spectecular fast-time index
% Note: you can search entire depth, but as in case of ice sounding data....
% ...bottom layers are typically withing 2000 to 3000, that's why I'm ...
% ...searching within that corresponding fast time indices.

function [ft_idx,index] = spec_rangeline(sardata,idx1,idx2)
        
        
pxx=20*log10(abs(sardata(idx1:idx2,:)));
rangeline=pxx(:,1);
index=1;
for kk=2:size(pxx,2)
     max1= max(rangeline);
     max2=max(pxx(1:size(pxx,1),kk));
    if max2>max1
        rangeline=pxx(:,kk);
      [y v]=max(rangeline);
      index=kk;
    end
end
ft_idx=15000+v;
end


