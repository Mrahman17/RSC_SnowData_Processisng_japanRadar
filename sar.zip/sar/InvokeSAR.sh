#!/bin/bash

declare -a channel_vector

function append_channel() {
    if [[ ! -f $1 ]]; then
        >&2 echo "Error: channel file $1 does not exist"
        return 1
    fi
    
    channel_string="'${1}'"
    channel_vector+=($channel_string)
    return 0
}

function read_output_dir() {
    if [[ ! -z ${output_dir+x} ]]; then
        >&2 echo "Error: duplicate output directory $1"
        return 1
    fi

    if [[ ! -d $1 ]]; then
        mkdir $1
    fi

    output_dir=$1
    return 0
}

function read_input_params() {
    if [[ ! -f $1 ]]; then
        >&2 echo "Error: input parameter file $1 does not exist"
        return 1
    fi

    if [[ ! -z ${input_params+x} ]]; then
        >&2 echo "Error: duplicate input parameter file $1"
        return 1
    fi

    input_params=$1
    return 0
}

function read_integer() {
    substitution=$(eval "echo \${$1+x}")

    if [[ ! -z $substitution ]]; then
        >&2 echo "Error: duplicate $2 $3"
        return 1
    fi

    if [[ $3 =~ ^[0-9]+ ]]; then
        eval "$1=$3"
        return 0
    else
        >&2 echo "Error: $3 is not a non-negative integer"
        return 1
    fi
}

function read_initial() {
    read_integer "initial" "initial column index" $1
    return $?
}

function read_length() {
    read_integer "length" "length" $1
    return $?
}

function read_stride() {
    read_integer "stride" "stride length" $1
    return $?
}

function read_chunks() {
    read_integer "chunks" "number of chunks" $1
    return $?
}

function read_threads() {
    read_integer "thread" "number of threads" $1
    return $?
}

function read_function() {
    matlab_func=$1
    return 0
}

function set_file_indexing() {
    file_indexing="true"
    return 0
}

function set_debug() {
    debug=1
    return 0
}

function set_dry_run() {
    dry=1
    return 0
}

function print_help() {
    cat InvokeSARHelpFile.txt 1>&2
}

function print_version() {
    >&2 echo "InvokeSAR.sh version 1 (July 1, 2019)"
    >&2 echo "Jack O'Donohue (jrodonohue@crimson.ua.edu)"
}

function read_command_line() {
    declare -A argument_handlers

    argument_handlers["-o"]="1 read_output_dir"
    argument_handlers["--output"]="1 read_output_dir"
    argument_handlers["-p"]="1 read_input_params"
    argument_handlers["--parameters"]="1 read_input_params"
    argument_handlers["-l"]="1 read_length"
    argument_handlers["--length"]="1 read_length"
    argument_handlers["-s"]="1 read_stride"
    argument_handlers["--stride"]="1 read_stride"
    argument_handlers["-c"]="1 read_chunks"
    argument_handlers["--chunk-number"]="1 read_chunks"
    argument_handlers["-ch"]="1 append_channel"
    argument_handlers["--channel"]="1 append_channel"
    argument_handlers["-i"]="1 read_initial"
    argument_handlers["--initial"]="1 read_initial"
    argument_handlers["-fn"]="1 read_function"
    argument_handlers["--function"]="1 read_function"
    argument_handlers["-t"]="1 read_threads"
    argument_handlers["--threads"]="1 read_threads"
    argument_handlers["-f"]="0 set_file_indexing"
    argument_handlers["--file-indexing"]="0 set_file_indexing"
    argument_handlers["-d"]="0 set_debug"
    argument_handlers["--debug"]="0 set_debug"
    argument_handlers["-dr"]="0 set_dry_run"
    argument_handlers["--dry-run"]="0 set_dry_run"
    argument_handlers["-h"]="0 print_help"
    argument_handlers["--help"]="0 print_help"
    argument_handlers["-v"]="0 print_version"
    argument_handlers["--version"]="0 print_version"

    local idx=1
    local failed=0

    while [ $idx -le "$#" ]; do
        arg=${!idx}
        idx=$((idx+1))

        if [[ -v argument_handlers[$arg] ]]; then
            invocation_info=${argument_handlers[$arg]}
            args="${invocation_info%% *}"
            fn="${invocation_info##* }"

            upper_idx=$((idx+args-1))

            if [[ $upper_idx -gt "$#" ]]; then
                >&2 echo "Error: not enough arguments for $arg option"
                failed=1
                break
            fi

            $fn ${@:idx:args}

            if [[ $? -ne 0 ]]; then
                failed=1
            fi

            idx=$((idx+args))
        else
            append_channel $arg
        fi
    done

    return $failed
}

function initialize_defaults() {
    if [[ -z ${output_dir+x} ]]; then
        read_output_dir "job_output/"
    fi

    if [[ -z ${input_params+x} ]]; then
        read_input_params "params.mat"

        if [[ $? -eq 1 ]]; then
            >&2 echo "Could not find default parameters file (\"params.mat\")"
            return 1;
        fi
    fi

    if [[ -z ${matlab_func+x} ]]; then
        matlab_func="sar_procedure"
    fi

    if [[ -z ${file_indexing+x} ]]; then
        file_indexing="false"
    fi

    if [[ -z ${stride+x} ]]; then
        stride=$length
    fi

    if [[ -z ${chunks+x} ]]; then
        chunks=1
    fi

    if [[ -z ${debug+x} ]]; then
        debug=0
    fi

    if [[ -z ${dry+x} ]]; then
        dry=0
    fi

    if [[ -z ${threads+x} ]]; then
        threads="0"
    fi
}

function check_command_line() {
    local failed=0

    if [[ -z ${initial+x} ]]; then
        >&2 echo "Error: initial index not specified"
        failed=1
    fi

    if [[ -z ${stride+x} ]]; then
        >&2 echo "Error: stride length not specified"
        failed=1
    fi

    if [[ -z ${chunks+x} ]]; then
        >&2 echo "Error: number of chunks to process not specified"
        failed=1
    fi

    if [[ -z ${length+x} ]]; then
        >&2 echo "Error: length of chunks not specified"
        failed=1
    fi

    if [[ ${#channel_vector[@]} -eq 0 ]]; then
        >&2 echo "Error: channels not specified"
        failed=1
    fi

    if [[ $failed -eq 1 ]]; then
        >&2 echo "Some parameters were missing. Run with \"-h\" for help"
    fi

    return $failed
}

function join() {
    local IFS=$1
    shift
    echo "$*"
}

function invoke_matlab() {
    array=$(join "," ${channel_vector[@]})
    array="{$array}"
    invocation="script_interface($array, '$input_params', $initial, $length, $stride, $chunks, $file_indexing, $threads, '$matlab_func', '$output_dir')"

    if [[ $debug -eq 1 ]]; then
        cmd="matlab -nodisplay -nodesktop -nosplash -r \"dbstop if error; $invocation\""
    else
        cmd="matlab -nodisplay -nodesktop -nosplash -r \"try; $invocation; catch ex; disp(ex); end; exit;\""
    fi

    if [[ $dry -eq 1 ]]; then
        echo $cmd
    else
        eval "$cmd"
    fi
}

read_command_line "${@:1}"

if [[ $? -eq 1 ]]; then
    failed=1
fi

initialize_defaults

if [[ $? -eq 1 ]]; then
    failed=1
fi

check_command_line

if [[ $? -eq 1 ]]; then
    failed=1
fi

if [[ $failed -ne 0 ]]; then
    exit 1
fi

invoke_matlab

