function [gps, user_params, files, columns] = load_fixed_params(job_channel_files, parameter_file)
    user_params = load(parameter_file);
    
    assert(isfield(user_params, 'mode'), ...
        strcat('The variable ''mode'' must be set in the file ''', ...
        parameter_file, ''' to load the data for SAR'));
    
    [~, column_list, gps_file] = read_job(job_channel_files{1});
    files = size(column_list, 1);
    columns = count_total_columns(column_list, user_params.mode);
    
    for i = 2:size(job_channel_files, 2)
        [~, column_list, gps_file] = read_job(job_channel_files{i});
        files = min(size(column_list, 1), files);
        columns = min(count_total_columns(column_list, user_params.mode), columns);
    end
    
    gps = parse_gps_data(gps_file);
end