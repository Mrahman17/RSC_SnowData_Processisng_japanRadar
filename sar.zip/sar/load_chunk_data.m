function [matrix_channels, counter_channels] = load_chunk_data(job_name_list, first_index, last_index, file_addressing, mode)
    % load matrices and counters
    matrix_channels = cell(size(job_name_list));
    counter_channels = cell(size(job_name_list));
    
    for i = 1:size(job_name_list, 2)
        [matrix_file_list, counter_file_list, ~] = read_job(job_name_list{i});
        
        if file_addressing
            matrix_span = matrix_file_list(first_index:last_index);
            counter_span = counter_file_list(first_index:last_index);
            [m, c] = load_chirps_and_counters(matrix_span, counter_span, mode);
        else
            [m, c] = load_column_span(matrix_file_list, counter_file_list, first_index, last_index, mode);
        end
        
        matrix_channels{i} = m;
        counter_channels{i} = c;
    end
end