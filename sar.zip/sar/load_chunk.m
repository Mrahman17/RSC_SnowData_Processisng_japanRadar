% Given a pair of file lists, and column indices within the file sequence,
% this function loads the subsequence of columns across the matrices.
% If one index is out of bounds, the resulting file is truncated. If both
% indices are out of bounds, either the entire span is returned when the
% span is between the indices, and otherwise, [] is returned.
function [chunk, cache] = load_chunk(matrix_file_list, counter_file_list, first_column, last_column, mode, cache)
    % The initial_column is needed to find the offset of first_column and
    % last_column in the subsequence of files [first_file, ..., last_file].
    [first_file, initial_column] = column_to_file(counter_file_list, first_column, mode);
    [last_file, ~] = column_to_file(counter_file_list, last_column, mode);

    % The entire chunk is out-of-bounds
    if (first_file == -1) & (last_file == -1) & (first_column > 0 | last_column <= 0)
        chunk = [];
        return;
    end
    
    % If the first or last files are out-of-bounds, truncate the
    % concatenated matrix
    if first_file == -1
        first_file = 1;
        first_column = 1;
        initial_column = 1;
    end
    
    if last_file == -1
        last_file = size(matrix_file_list, 2);
        last_column = count_total_columns(counter_file_list, mode);
    end

    % Reduce locations of columns to offsets in the subsequence of matrix files
    % matrix_file_list(first_file:last_file)
    first_column = first_column - initial_column;
    last_column = last_column - initial_column;

    [chunk, cache] = load_matrix_files_sequential(matrix_file_list(first_file:last_file), mode, first_column, last_column, cache);
end
