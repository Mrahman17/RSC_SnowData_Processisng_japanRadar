
%% Interpolate in gps latitude, longitude and altitude
%% Inputs;
%% 1.gpsfullpath: '/mnt/HDD03/logs/20180820_073902_CTU-CTU_gps.txt';
%% 2.st_vector: concatenated PPS-counter vector 
%% 3.numPulses: slow-time dimention
%%


function [lat,lon,elev] = gps_interp(gpsfullpath,st_vector,numPulses)

  
        % Parse gps file
        
        gps = parse_gps_data(gpsfullpath);
        
        
        % find index corresponding to st_vector
        m=min(find(gps.ppsCntr==st_vector(1)));
          if isempty (m)
                m=1;
         end
        n=min(find(gps.ppsCntr==st_vector(end)));
        
        deno=length(gps.ppsCntr)/length(gps.latitude);
        
        idx1=ceil(m/deno);
        idx2=floor(n/deno); %using floor to ensure not jumping into other files's gps coord.
        
        % Crop in latitude,Longitude & Altitude Vector

                gps_lat=gps.latitude(idx1:idx2);
                gps_lon=gps.longitude(idx1:idx2);
                gps_alt=gps.altitude(idx1:idx2);
                
                % Interpolation
                
                elev = spline(linspace(1,numPulses,idx2-idx1+1),gps_alt,...
                        linspace(1,numPulses,numPulses));
                
                lat = spline(linspace(1,numPulses,idx2-idx1+1),gps_lat,...
                        linspace(1,numPulses,numPulses));
                
                
                lon = spline(linspace(1,numPulses,idx2-idx1+1),gps_lon,...
                        linspace(1,numPulses,numPulses));
                
 
        
end
