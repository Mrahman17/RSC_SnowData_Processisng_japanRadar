
% =========================================================================
% This Function is the core of all Processing
% Steps:
% 1. Load the data and counter files
% 2. load Gps file and interpolate latitude, longitude and altitude accordingly
% 3. find along Track distance vector
% 4. pulse compression
% 5. narrow beam motion compesnaiton
% 6. F-K migration
% Written by: Mahbub, UA RSC, Date: 06/25/2019
% =========================================================================
function [sardata,dist] =get_sar_data(load_data_param,radar_param,sar_param, channel)
        
        first_file_number=load_data_param.first_file_number;
        num_files=load_data_param.num_files;
        directory= load_data_param.data_directory;
        file_prefix= load_data_param.file_prefix;
        mode=load_data_param.mode;   % it's the long mode/short mode
        
        
        [data, counters] = load_chirps_and_counters_sar(first_file_number, num_files, directory, file_prefix, channel,mode,radar_param);
        st_tmp=counters;
        
        % Remove DC offset across azimuth
        %data=data -mean(data,2); %Coherent noise removal
        [M1,N1]= size(data);
        datain = data;
        for ii = 1:N1
            datainf(:,ii) = datain(:,ii)-mean(datain(2e4:2.2e4,ii));   %sy
        end;
        data = datainf;
        
        fs=radar_param.fs;
        dt=1/fs; %due to complex sampling; sampling at 500 MHz I/Q
        ft=0:dt:(M1-1)*dt;
        c=3e8;
        c_ice=3e8/sqrt(3.15);
       % range=(ft-0.212e-6)*3e8/sqrt(3.15)/2;
       % find the range vector
rcable=5/4*(6+6+9.5+1.143)*2;
tdel=1*10^(-6);
range=(ft-tdel+3000/(1e9))*3e8/sqrt(3.15)/2-rcable;
        
        % Load gps
        gps_path=load_data_param.gps_fullpath;
        display('Loading GPS...')
        numPulses = size(data,2);
        [lat,lon,elev] = gps_interp(gps_path,st_tmp,numPulses); %get interpolated elevation vector from gps file
        
        
        dist=0;
        for ii=1:length(lat)-1
                dist(ii+1) = dist(ii)+sw_dist([lat(ii) lat(ii+1)],[lon(ii) lon(ii+1)],'km')+0*1e-6;
        end
        
        
        
        
        display('Pulse Compression...')
        % set the parameters for Pulse Compression
        radar_param.T=max(ft);
        dopt=1; % decimation option: if 1, then decimaiton is on, otherwise no decimation
        dec=radar_param.dec;
        mode=0; % set mode to 1 if you want to get Pulse compressed data in time domain
        [data_pc,~] = PComp(data,radar_param,dopt,dec,mode); % data_pc is now in freq domain as mode is 0
        clear data;
        
        % figure(60); plot(20*log10(abs((data_pc(:,1000)))));
        % title('A-scope of Pulse Compressed data in time domain');
        % xlabel('Range (m)')
        % ylabel('Power in dB')
        % grid on;
        % figure; imagesc(20*log10(abs(data_pc))); colormap(1-gray);
        %generate echogram after Pulse compression
        td_data_pc= ifft(data_pc); % convert in time domain for echogram
        td_data_pc=td_data_pc(1:M1,:);
        
%         figure(70); imagesc(dist,range,20*log10(abs(td_data_pc))); colormap(1-gray);
%         title('Echogram after Pulse compression'); xlabel('Distance(km)');ylabel('Range (m)');
%         ylabel('Range (m)'); ylim([600 3500])
        
        
        
        display('mocomp...')
        % motion compensation
        [npts,numPulses]=size(data_pc);
        delZ= elev-mean(elev);
        type=0;
        mocomp_data = mocompgen(data_pc,fs,numPulses,npts,delZ,type);
        clear data_pc;
        
        % plot output of motion compensation
        %generate echogram after Pulse compression
        td_data_pc= ifft(mocomp_data); % convert in time domain for echogram
        td_data_pc=td_data_pc(1:M1,:);
        
%         figure(71); imagesc(dist,range,20*log10(abs(td_data_pc))); colormap(1-gray);
%         title('Echogram after Pulse compression and mocomp'); xlabel('Distance(km)');ylabel('Range (m)');
%         ylabel('Range (m)'); ylim([600 3500])
%         
        
        % Coherent Integration
%         sigData=coh_avg_dec(mocomp_data,radar_param.coh_avg);
%         lat_dec=downsample(lat,radar_param.coh_avg);
%         lon_dec=downsample(lon,radar_param.coh_avg);
%         st_dec=downsample(st_tmp,radar_param.coh_avg);
        
        % F-K Migration
        display('f-k Migration...')
        % Set up the SAR parameters
       
        
        sigData   = fftshift(mocomp_data,1);
        %sigData   = mocomp_data; %fft in depth direction is taken in mocomp_data
        numPulses = size(sigData,2); 
        delAz = sar_param.delAz 
        %delAz = 0.0434;
        delAzgps = 1000*(dist(end)-dist(1))/numPulses
        %sar_param.delAz;           
        %fc        = 250*10^(6); %radar_param.fnco;           % centre freq 200e9
        fc        = radar_param.fc;
        fs        = radar_param.fs;
        npts      = size(sigData,1);
        eps2      = sar_param.eps2;            % Dielectric constant for Ice
        h         = sar_param.h;               % Elevation of the platform from the imaging surface
        beamwidth = sar_param.beamwidth;       % Beamwidth in Radian
        dmax      =sar_param.max_depth;        % depth to bottom layer
        clear mocomp_data;
        
        sardata = rma2L_with_KF(sigData,numPulses,delAz,fs,fc,npts,eps2,h,beamwidth,dmax);
        
        sardata=sardata.';
        sardata= sardata(1:M1,:); %get rid of zero padded (during pulse compressoin)extra samples
        
%         dist=0;
%         for ii=1:length(lat_dec)-1
%                 dist(ii+1) = dist(ii)+sw_dist([lat_dec(ii) lat_dec(ii+1)],[lon_dec(ii) lon_dec(ii+1)],'km')+0*1e-6;
%         end
        
        
        figure(100);imagesc(20*log10(abs(sardata/max(max(abs(sardata))))))
        title('SAR Data focused using Range Migration algorithm ')
        xlabel('Distance (km)')
        ylabel('Range (m)')
        colormap(1-gray);
        
        
        H3=figure;
        imagesc(dist,range,20*log10(abs(sardata)/max(max(abs(sardata)))))
       title([file_prefix(1:8) '-' file_prefix(10:15)...
        '-Channel-' num2str(channel) '-SAR-echogram-files-' num2str(first_file_number) '-' ...
        num2str(first_file_number+num_files -1)]);
      xlabel('Dist (km)'); ylabel('range (m) [\epsilon_i_c_e = 3.15]')
        ylim([600 3500]);
        colormap(1-gray);
        
         %save_figure;
%         fig_name=[load_data_param.file_prefix num2str(channel) '_files_' num2str(first_file_number) '_' ...
%                  num2str(first_file_number+num_files -1) '.fig'];
%         full_fig_name=[load_data_param.save_fig_dir fig_name];
%         savefig(H3,full_fig_name,'compact');



