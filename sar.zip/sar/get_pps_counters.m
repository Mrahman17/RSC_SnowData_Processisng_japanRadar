function counters = get_pps_counters(counter_file_list, mode,radar_param)
    chunks = cell(size(counter_file_list, 1));

    for i = 1:size(counter_file_list, 1)
        chunks{i} = load(string(counter_file_list(i)));
        chunks{i} = chunks{i}.Counters(mode + 1).PPS_Counters;
    end

    length = 0;

    for i = 1:size(counter_file_list, 1)
        length = length + size(chunks{i}, 2);
    end

    counters = zeros(1, length);
    prev_index = 1;

    for i = 1:size(counter_file_list, 1)
        counters(prev_index:prev_index + size(chunks{i}, 2) - 1) = chunks{i};
        prev_index = prev_index + size(chunks{i}, 2);
    end
    if radar_param.coh_avg~=0
        counters= downsample(counters,radar_param.coh_avg);
    end
end
