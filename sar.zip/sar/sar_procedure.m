function sar_procedure(data, counters, gps_data, user_params, figure_print_path)
    % Get SAR-Processed Echogram from all the channels
    num_channel = size(data, 2);
    arr = cell(num_channel, 1); % define a cell arry to sar processed data for all the channels

    % extract info from file
    radar_param = user_params.radar_param;
    sar_param = user_params.sar_param;
    
    for channel=1:num_channel
        [arr{channel}, dist] = get_sar_data(data{channel}, counters{channel}, gps_data, radar_param, sar_param, channel - 1, figure_print_path);
    end

    save SARresults.mat;
    
    % Array Processing

    % Consider Channel 0 as reference channel, but because of MATLAB indexing, you
    % should use 1 to represent channel 0

%     ref_channel=1;
%     % Specify the depth intervels that contains bottom layer
%     depth1=2000;
%     depth2= 3000;
% 
%     [multi_ch_data,range,st_idx] = Phase_Amp_comp(arr,ref_channel,num_channel,radar_param,depth1,depth2);
%     clear arr; % clear the cell arry variable.
% 
%     fig = figure(992); imagesc(dist,range,20*log10(abs(multi_ch_data)));colormap(1-gray);ylim([996,3320])
%     title('Echogram after adding 4 channels');xlabel('Dist (km)'); ylabel('range (m)')
% 
%     %if figure_print_path ~= ""
%     %    print(fig, fullfile(figure_print_path, "four_channel_echogram.png"), "-dpng");
%     %end
% 
%     % Dtrending the data
%     [dtrnd_echo,dtrn_range] = echogram_detrending(multi_ch_data,range,st_idx);
% 
%     %Apply Median Filter
%     dtrnd_echo=medfilt2(dtrnd_echo,[1,5]);
% 
%     fig = figure(420); imagesc(dist,dtrn_range,dtrnd_echo); colormap(1-gray)
%     xlabel('Distance (m)'); ylabel('range (m)');title('Echogram after Detrending')
% 
%     if figure_print_path ~= ""
%         print(fig, strcat(figure_print_path, "_echogram_after_detrending.png"), "-dpng");
%     end
% 
% %     fig = figure(101); plot(dtrnd_echo(:,st_idx));grid on;
% %     title('A-Scope after Detrending'); 
% 
% %     if figure_print_path ~= ""
% %         print(fig, strcat(figure_print_path, "_a_scope_after_detrending.png"), "-dpng");
% %     end
% end