function script_interface(job_channel_files, parameter_file, initial, length, stride, chunks, file_addressing, num_threads, funcStr, print_path)
    [gps, user_params, file_count, column_count] = load_fixed_params(job_channel_files, parameter_file);
    
    fn = str2func(funcStr);
    
    pool = gcp('nocreate');
    
    if isempty(pool)
        if num_threads == 0
            parpool;
        else
            parpool(num_threads);
        end
    end
    
    if chunks == 0
        if file_addressing
            limit = file_count;
        else
            limit = column_count;
        end
    else
        limit = initial + stride * (chunks - 1);
    end
    
    mode = user_params.mode;
    
    for first_index = initial:stride:limit
        last_index = first_index + length - 1;
        
        if print_path == ""
            output_dir = "";
        else
            output_dir = fullfile(print_path, strcat(num2str(first_index), "_", num2str(last_index)));
        end
        
        [matrix_channels, counter_channels] = load_chunk_data(job_channel_files, first_index, last_index, file_addressing, mode);
        fn(matrix_channels, counter_channels, gps, user_params, output_dir);
    end
end
