%Chirp signal generation for UHF radar
% This is a sub-function of 'Pcomp_uhf.m'



% ref chirp signal
function ref_chirp_signal=chirpsignal_uhf( radar_param, cuttoff_freq, filt_type)
%clear all;close all;clc
fs  =radar_param.fs;
Tpd = radar_param.tp;
data_fnco=radar_param.data_fnco;
i=sqrt(-1);
f0  = radar_param.f0 - fs; % 100 MHz
f1  = radar_param.f0+radar_param.BW - fs; % 400 Mhz
Nref  = Tpd*fs;
dt = 1/fs;
BW = f1-f0;
time = (0:dt:(Nref-1)*dt).';
alpha = BW / Tpd;
fc = (f0 + f1)/2;
ref0 = exp(i*2*pi*f0*time + i*pi*alpha*time.^2);

% apply taper function
Htukeywin = tukeywin(Nref+2,0.1);
Htukeywin = Htukeywin(2:end-1);
ref0 = Htukeywin.*ref0;

% Generate complex data
dataI=real(ref0).*cos(2*pi*data_fnco*time);
dataq=imag(ref0).*sin(2*pi*data_fnco*time);

lof = designfilt(filt_type, 'PassbandFrequency', cuttoff_freq, ...
                 'StopbandFrequency', cuttoff_freq+25e6, ...
                 'PassbandRipple', 0.25, 'StopbandAttenuation', 45, ...
                 'SampleRate', fs);
dataI=filtfilt(lof,dataI);
dataq=filtfilt(lof,dataq);
datacomplex=dataI+i*dataq;
n = pow2(nextpow2(Nref));
chirpfreq=fftshift(fft(datacomplex,n));
N=6555-1639; %Indexes for 150 MHz and -150 MHz
hanwin=hanning(N);
chirpweight=chirpfreq(1639:6554).*hanwin;

chirpw=[chirpfreq(1:1638); chirpweight; chirpfreq(6555:8192)];
%chirppowerdb=10*log10(chirppower);
% f=((-n/2:n/2-1)/n)*fs;
% figure;
% plot(f,(chirpw));title('Chirp spectrum');
% grid
ref_chirp_signal=ifft(chirpw);
end