% This function concatenates the matrices in the file array
% matrix_file_list(first_file_index:last_file_index)
function concatenated = load_concatenated_files(matrix_file_list, counter_file_list, first_file_index, last_file_index, mode)
    total_columns = count_total_columns(counter_file_list(first_file_index:last_file_index));
    
    % Track the last location that we wrote to in the concatenated matrix
    previous_index = 0;
    
    for i = first_file_index:last_file_index
        sub_matrix = get_chirps(matrix_file_list(i), mode);
        
        % The preallocation is delayed because we don't know the number of
        % rows until now.
        if size(concatenated) == 0
            concatenated = zeros(size(sub_matrix, 1), total_columns);
        end
        
        concatenated(previous_index + 1:previous_index + size(submatrix, 2)) = submatrix;
        previous_index = previous_index + size(submatrix, 2);
    end
end