function [data_out]=incoh_avg(data_in,avg_length)
avg=avg_length;
if avg==0
    data_out=data_in;
else
    [m,n]=size(data_in);
    for ii=1:n
        if ii>avg && ii<n-avg
            data_out(:,ii)=mean(abs(data_in(:,ii-avg:ii+avg)),2);
        else
            data_out(:,ii)=data_in(:,ii);
        end
    end
end