% Given a counter file, this function computes the total number of columns
% within the file.
function length = count_matrix_columns(filename, mode)
    contents = load(string(filename));
    length = size(contents.Counters(mode + 1).PPS_Counters, 2);
end
