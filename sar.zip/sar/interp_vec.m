function yi = interp_vec(x,y,xi)


m = length(y);

% Find indices of subintervals, x(k) <= xi < x(k+1) 
[ignore,k] = histc(xi,x);
k(k == m) = m-1;
ndx_noninterpable = find(k == 0);
k(k == 0) = 1;

% Linearly interpolate
dx = diff(x);
dy = diff(y);
yi = y(k) + (xi - x(k)).*dy(k)./dx(k);
yi(ndx_noninterpable) = NaN;