% Specify Radar parameters
radar_param.fs      = 1e9/2;   % adc sampling frequency
radar_param.BW      = 60e6;    % Bandwidth
radar_param.f0      = 170e6;   % starting frequency
radar_param.Fs      = 2000e6;  % DAC (Tx) sampling frequency
radar_param.tp      = 10e-6;   % Pulse Duration
radar_param.fnco    = 250e6;   % nco mixer freq.
radar_param.dec     = 4;       % Decimation
radar_param.fc      = 200e6;   % Center Frequency
radar_param.coh_avg = 8;       % coherent avg length

% Specify SAR parameters
sar_param.eps2      = 3.15;      % Dielectric constant of the medium you are imaging
sar_param.max_depth = 2800;      % Depth of bottom layer in terms of meters
sar_param.delAz     = 4;         % SAR Resulation 
sar_param.h         = 0;         % Distance of the Platform from the surface
sar_param.beamwidth = 1.3*pi/180;

save('default_params.mat');