function [data_out]=coh_avg_dec(data_in,avg_length)
avg=avg_length;
if avg==0
    data_out=data_in;
else
    aa=1;
    [m,n]=size(data_in);
    for ii=1:avg:n
        
        display(['Coherent integration: ' num2str(ii) '/' num2str(n)])
%         if ii<n-avg
%             data_out(:,aa)=mean(data_in(:,ii:ii+(avg-1)),2);
%             aa=aa+1;
%         else
% 
%             data_out(:,aa)=mean(data_in(:,ii:n),2);
%             aa=aa+1;
%         end
%     end
% end
        
        
        
        if ii>avg && ii<n-avg
            data_out(:,aa)=mean((data_in(:,ii-avg:ii+avg)),2);
        else
            data_out(:,aa)=data_in(:,ii);
        end
        aa=aa+1;
    end
end