function [data_dec,t_dec]=DDC(data_rf,f_NCO,t,Ndec)

data_I=data_rf.*cos(2*pi*-f_NCO*t);
data_Q=data_rf.*sin(2*pi*-f_NCO*t);

data_I_dec=decimate(data_I,Ndec,'fir');
data_Q_dec=decimate(data_Q,Ndec,'fir');

data_dec=data_I_dec+1j*data_Q_dec;
data_dec=data_dec/max(abs(data_dec));

t_dec=t(1:Ndec:end);


t_dec=downsample(t,Ndec);