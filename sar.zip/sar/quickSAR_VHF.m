%%%%%%%%%%%%%%%%%%%%%%
%% QUICK SAR SCRIPT %%
%%    VHF RADAR     %% 
%%%%%%%%%%%%%%%%%%%%%%

clc; clear all;close all;


% Specifiy paraemeters of data loading 
load_data_param.first_file_number=76; % first file index 
load_data_param.num_files=24;           % number of files you want to process

load_data_param.data_directory= '/media/radarops/c00/VHF_data/';
load_data_param.gps_fullpath= '/media/radarops/c00/VHF_data/20180820_073902_CTU-CTU-gps.txt';
load_data_param.file_prefix= '20180820_073902_Channel';
load_data_param.save_fig_dir= '/media/radarops/c00/VHF_data/Results'; %directory for saving the .fig files
% load_data_param.data_directory='/mnt/HDD03/Greenland2018/raw_files/yolo2/';
% load_data_param.gps_fullpath= '/mnt/HDD03/Greenland2018/concat_file/20180820_073902_CTU-CTU-gps.txt';
% load_data_param.save_fig_dir= '/mnt/HDD03/Greenland2018/raw_files/yolo2/'; %directory for saving the .fig files
% load_data_param.file_prefix= '20180820_073902_Channel';
load_data_param.chunk_size=20000;      % num of columns = num of pulses reqiure to form an aperture size
load_data_param.padding_size=1000;     % num of columns to be padded on each side of a chunk
load_data_param.mode=0; % depends on which mode (ex. long/short) of data the .mat file contains
                        % long mode=0; short mode=3;
                        
% Specify Radar parameters
radar_param.fs=1e9/2;   % adc sampling frequency
radar_param.BW=60e6;    % Bandwidth
radar_param.f0=170e6;   % starting frequency
radar_param.Fs=2000e6;  % DAC (Tx) sampling frequency
radar_param.tp=10e-6;   % Pulse Duration
radar_param.fnco=250e6; % nco mixer freq.
radar_param.dec =4;     % Decimation
radar_param.fc  =200e6; % Center Frequency
radar_param.coh_avg= 8;  % coherent average length

% Specify SAR parameters
sar_param.eps2= 3.15;      % Dielectric constant of the medium you are imaging
sar_param.max_depth =2800; % Depth of bottom layer in terms of meters
sar_param.delAz= 4;        % SAR Resulation 
sar_param.h    = 0;        % Distance of the Platform from the surface
sar_param.beamwidth= 1.3*pi/180; 
                           % Antenna Beamwidth in radian

% Get SAR-Processed Echogram from all the channels

num_channel=4; % Total Number of channels
arr=cell(num_channel,1); % define a cell arry to sar processed data for all the channels
dist=cell(num_channel,1);

 for channel=1:num_channel
         [arr{channel},dist{channel}]=get_sar_data(load_data_param,radar_param,sar_param, channel-1);
 end
 
% Array Processing
% Consider Channel 0 as reference channel, but because of MATLAB indexing, you
% should use 1 to represent channel 0

ref_channel=1;
% Specify the depth intervels that contains bottom layer
depth1=2000;
depth2= 3000;

if num_channel > 2 % as for array proc., we need more than 2 channels
        
        
        
        [multi_ch_data,range,st_idx] = Phase_Amp_comp(arr,ref_channel,num_channel,radar_param,depth1,depth2);
        clear arr; % clear the cell arry variable.
        
        H1=figure;
        imagesc(dist{1},range,20*log10(abs(multi_ch_data)));colormap(1-gray);
        title([load_data_param.file_prefix(1:8) '-' load_data_param.file_prefix(10:15)...
                '-All Channels-files-' num2str(load_data_param.first_file_number) '-' ...
                num2str(load_data_param.first_file_number+load_data_param.num_files -1)]);
        xlabel('Dist (km)'); ylabel('range (m) [\epsilon_i_c_e = 3.15]');
        ylim([996,3320]);
        
         %save_figure;
%         fig_name=[load_data_param.file_prefix(1:15) '_All_cahnnels_files_' num2str(load_data_param.first_file_number) '_' ...
%                 num2str(load_data_param.first_file_number+load_data_param.num_files -1) '.fig'];
%         full_fig_name=[load_data_param.save_fig_dir fig_name];
%         savefig(H1,full_fig_name,'compact');
        
        % Dtrending the data
        [dtrnd_echo,dtrn_range] = echogram_detrending(multi_ch_data,range,st_idx);
        
        %Apply Median Filter
        dtrnd_echo=medfilt2(dtrnd_echo,[1,5]);
        
        H2=figure;
        imagesc(dist{1},dtrn_range,dtrnd_echo); colormap(1-gray)
        title([load_data_param.file_prefix(1:8) '-' load_data_param.file_prefix(10:15)...
                '-After Detrending-files-' num2str(load_data_param.first_file_number) '-' ...
                num2str(load_data_param.first_file_number+load_data_param.num_files -1)]);
        xlabel('Dist (km)'); ylabel('range (m) [\epsilon_i_c_e = 3.15]')
        
        %save_figure;
        fig_name=[load_data_param.file_prefix(1:15) '_After_Detrending_files_' num2str(load_data_param.first_file_number) '_' ...
                num2str(load_data_param.first_file_number+load_data_param.num_files -1) '.fig'];
        full_fig_name=[load_data_param.save_fig_dir fig_name];
        savefig(H2,full_fig_name,'compact');
        
end
