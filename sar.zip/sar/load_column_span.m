function [matrix, counters] = load_column_span(matrix_file_list, counter_file_list, first_col, last_col, mode)
    [first_file, offset] = column_to_file(counter_file_list, first_col, mode);
    [last_file, ~] = column_to_file(counter_file_list, last_col, mode);
    
    matrix_file_span = matrix_file_list(first_file:last_file);
    counter_file_span = counter_file_list(first_file:last_file);
    
    [matrix, counters] = load_chirps_and_counters(matrix_file_span, counter_file_span, mode);
    
    lower_bound = first_col - offset;
    upper_bound = last_col - offset;
    
    matrix = matrix(lower_bound:upper_bound);
    counters = counters(lower_bound:upper_bound);
end