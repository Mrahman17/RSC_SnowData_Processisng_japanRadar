%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                          MOTION COMPENSATION                        %%%
%%%                                                                     %%%
%%%                             Sevgi Z. Gurbuz                         %%%    
%%%                           Md. Mahbubur Rahman                       %%%
%%%                          The University of Alabama                  %%%
%%%                           Remote Sensing Center                     %%% 
%%%                               Date: 6/22/19                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function data = mocompgen(rangecmps0,fs,numPulses,npts,delZ,type)

% Input parameters
% rangecmps0:  range compressed data matrix in (frequency, slow-time)
% fs : sampling frequency
% numPulses : number of slow-time pulses 
% npts : number of fast-time samples
% delZ : elevation error as a function of slow time
% type : selection of narrowbeam versus widebeam motion compensation
%        default is narrowbeam; for widebeam, set type = 1  
% Output: Data-> in Frequency domain
c = 3*10^8;

% compute fft across fast-time of range compressed data matrix 


if type == 1,
    % Widebeam motion compensation
    
else
% Narrowbeam motion compensation
for idx = 1:numPulses,
    rcmprs = rangecmps0(:,idx);
    wv_num_v = 2*pi*linspace(-fs/2,fs/2-fs/npts,npts)/(c*fs);
    mocomp = exp(j*2*wv_num_v.'*delZ(idx)*fs);
    rcmprs = fftshift(rcmprs) .* mocomp;
    data(:,idx) =(fftshift(rcmprs));
end; % endfor

end; %endif
    
