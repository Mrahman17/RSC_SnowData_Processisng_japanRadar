function [matrix_files, counter_files] = make_file_list(first_file_number, num_files, directory, file_prefix, channel)
    matrix_files = cell(num_files, 1);
    counter_files = cell(num_files, 1);

    for i = 0:num_files - 1
        base_filename = strcat(directory, file_prefix, num2str(channel), '_', num2str(i + first_file_number, '%04d'));
        matrix_files{i + 1} = strcat(base_filename, '.mat');
        counter_files{i + 1} = strcat(base_filename, '_counters.mat');
    end
end
