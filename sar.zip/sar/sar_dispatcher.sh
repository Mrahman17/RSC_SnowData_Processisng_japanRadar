#!/bin/bash

dat_array=()
parent_dir=$1	#this would be the location of the storage drives
declare -A dict_gps

scan_for_gps() {
	if [ -d $parent_dir ]; then	#if the folder exists
		cd $parent_dir
		for f in $(find "$PWD" -type f | grep 'gps.txt'); do
			time_stamp_gps=`echo $f | sed 's#.*/##g'`
			time_stamp_gps=${time_stamp_gps:0:16}
			if [ -z ${dict_gps[$time_stamp_gps]} ]; then
				dict_gps+=([$time_stamp_gps]=$f)
			fi
		done
	else
		echo $parent_dir does not exist
		exit 1
	fi
	cd
}
###Done with GPS

add_mat_files() {
	cd $parent_dir

	for f in $(find "$PWD" -type f | grep '.mat'); do
		if [ ! "${f: -12}" == "counters.mat" ]; then
			curr_file=`echo $f | sed 's#.*/##g'`
			time_stamp_mat=${curr_file:0:16}
			gps_file=${dict_gps[$time_stamp_mat]}
			if [ ! -z $gps_file ]; then
				cd
				echo $f, $gps_file >> sar/sar_joblist.txt
			fi
		fi
	done
}

rm sar_joblist.txt
echo removing sar_joblist.txt
scan_for_gps
echo gps_array Populated
add_mat_files
echo created sar_joblist.txt
