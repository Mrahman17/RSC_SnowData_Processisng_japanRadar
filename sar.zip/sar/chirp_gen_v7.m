function [chirp_signal,chirp_time]=chirp_gen_v7(radar_param,delay,win)

radar_param.chirp_rate=radar_param.BW /radar_param.tp;
radar_param.dt = 1/radar_param.Fs;
dt=radar_param.dt;

time_pulse=0:radar_param.dt:radar_param.tp;
time=0:radar_param.dt:radar_param.T;

chirp_signal0=exp(1i*2*pi*radar_param.f0*(time_pulse)+1i*pi*radar_param.chirp_rate*(time_pulse).^2);
%chirp_signal0 = chirp(time_pulse,radar_param.f0,radar_param.tp,radar_param.f0+radar_param.BW);
%chirp_signal0=sin(2*pi*(radar_param.f0+(radar_param.chirp_rate*(time_pulse)/2)).*(time_pulse));

if win==0
    chirp_win=rectwin(length(chirp_signal0)).';
elseif win==1
    chirp_win=blackmanharris(length(chirp_signal0)).';
elseif win==2
    chirp_win=tukeywin(length(chirp_signal0),0.05).';
elseif win==3
    chirp_win=blackman(length(chirp_signal0)).';
elseif win==4
    chirp_win=hanning(length(chirp_signal0)).';
elseif win==5
    chirp_win=hamming(length(chirp_signal0)).';
end

chirp_signal=[zeros(1,round(delay/dt)) chirp_signal0.*chirp_win  zeros(1,length(time)-length(chirp_signal0)-round(delay/dt))];

chirp_signal=chirp_signal/max(abs(chirp_signal));
chirp_time=time;
