
% =========================================================================
% qlook_VHF_2019
% Steps:
% 1. Load Data and counters, performs coherent integration during loading files
% 2. Pulse compression
% 3. load GPS, find along Track Distance
% 4. Incoherent interation
% 5. Plot the result
% =========================================================================

clc; clear all; close all;

% Specify data loading parameters
first_file_number=61; % Don't add zeros on the left side 
num_files= 38;
data_directory= '/media/radarops/c00/VHF_data/';
gps_fullpath= '/media/radarops/c00/VHF_data/20180820_073902_CTU-CTU-gps.txt';
file_prefix= '20180820_073902_Channel';
mode=0;   % it's the long mode/short mode 
channel=0;

% Specify Radar Parameters
radar_param.fs=1e9/2;    % ADC sampling frequency
radar_param.BW=60e6;     % Bandwidth
radar_param.f0=170e6;    % starting frequency
radar_param.Fs=2000e6;   % DAC (Tx) sampling frequency
radar_param.tp=10e-6;    % Pulse Duration
radar_param.fnco=250e6;  % nco mixer freq.
radar_param.dec =4;      % Decimation
radar_param.fc  =200e6;  % Center Frequency
radar_param.coh_avg= 8;  % coherent average length, put a 0 if you don't performs coh_avg
radar_param.Incoh_avg= 5;% Incoherent average length,put a 0 if you don't performs Incoh_avg
% =========================================================================

% load data, and GPS
[data, counters] = load_chirps_and_counters(first_file_number, num_files, data_directory, file_prefix, channel,mode,radar_param);
st_tmp=counters;
disp('Loading GPS...')
numPulses = size(data,2);
[lat,lon,elev] = gps_interp(gps_fullpath,st_tmp,numPulses); 

% Find fast-time vector
[M1,N1]= size(data);
fs=radar_param.fs;
dt=1/fs; %due to complex sampling; sampling at 500 MHz I/Q
ft=0:dt:(M1-1)*dt;

% Pulse Compression
radar_param.T=max(ft);
dopt=1; % decimation option: if 1, then decimaiton is on, otherwise no decimation
dec=radar_param.dec;
mode=1; % set mode to 1 to get time domain pulse compessed data
[data_pc,surface_time] = PComp(data,radar_param,dopt,dec,mode); 
clear data;


% find the range vector
range=(ft-surface_time)*3e8/sqrt(3.15)/2;

% Slow time decimation and averaging
disp('Slow time decimation and averaging...')

data_incoh_avg=incoh_avg_dec(data_pc,radar_param.Incoh_avg);
lat_dec=downsample(lat,radar_param.Incoh_avg);
lon_dec=downsample(lon,radar_param.Incoh_avg);
st_dec=downsample(st_tmp,radar_param.Incoh_avg);

datanorm=20*log10(abs(data_incoh_avg));
datanorm=datanorm-max(max(datanorm));

clear data_pc;
clear data_coh_avg;

dist=0;
for ii=1:length(lat_dec)-1
    dist(ii+1) = dist(ii)+sw_dist([lat_dec(ii) lat_dec(ii+1)],[lon_dec(ii) lon_dec(ii+1)],'km')+0*1e-6;
end



figure(6);clf
imagesc(dist,range,datanorm)
colormap(1-gray)
xlabel('Distance (km)');ylabel('Distance (m) [\epsilon_i_c_e = 3.15]');
ylim([600 3000]);
set(gca,'ytick',-200:200:3000)
set(gca,'xtick',round(dist(1:200:end),3))
caxis([-100 0]);
title([file_prefix(1:8) '-' file_prefix(10:15)...
                '-Channel-' num2str(channel) '-files-' num2str(first_file_number) '-' ...
        num2str(first_file_number+num_files -1)]);



