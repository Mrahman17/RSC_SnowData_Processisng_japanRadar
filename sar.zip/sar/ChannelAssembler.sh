#!/bin/bash

default_classify="sed -n \"s/[0-9]\{4\}\.mat//p\" | xargs -l basename"
default_index="sed -n \"s/.*\([0-9]\{4\}\)\.mat/\1/p\"" #"sed -n \"s/.*[0-9]\{8\}_[0-9]\{6\}_Channel[0-9]_\([0-9]\{4\}\)\.mat/\1/p\""
default_counters="sed -n \"s/\.mat/_counters.mat/p\"" #"sed -n \"s/\.mat/_counters.mat/p\""

function do_classify() {
    eval "echo $1 | $classify"
}

function do_index() {
    eval "echo $1 | $index"
}

function do_counters() {
    eval "echo $1 | $counters"
}

function set_string() {
    if [[ -v $1 ]]; then
        >&2 echo "Error: additional $3 \"$2\" specified"
        return 1
    else
        eval "$1=$2"
        return 0
    fi
}

function set_classify() {
    set_string "classify" "$1" "classify"
    return $?
}

function set_index() {
    set_string "index" "$1" "index"
    return $?
}

function set_counters() {
    set_string "counters" "$1" "counters"
    return $?
}

function set_classify_regex() {
    set_classify "sed -n \"s${1}p\""
    return $?
}

function set_index_regex() {
    set_index "sed -n \"s${$1}p\""
    return $?
}

function set_counters_regex() {
    set_counters "sed -n \"s${$1}p\""
    return $?
}

function set_input_file() {
    set_string "input_file" "$1" "input file"
    return $?
}

function set_output_file() {
    set_string "output_file" "$1" "output file"
    return $?
}

function print_help() {
    cat ChannelAssemblerHelpFile.txt 1>&2
}

function print_version() {
    >&2 echo "ChannelAssembler.sh version 1 (July 4, 2019)"
    >&2 echo "Jack O'Donohue (jrodonohue@crimson.ua.edu)"
}

function parse_command_line() {
    declare -A arguments
    arguments["-cl"]="1 set_classify"
    arguments["--classify"]="1 set_classify"
    arguments["-clr"]="1 set_classify_regex"
    arguments["--classify-regex"]="1 set_classify_regex"
    arguments["-i"]="1 set_index"
    arguments["--index"]="1 set_index"
    arguments["-ir"]="1 set_index_regex"
    arguments["--index-regex"]="1 set_index_regex"
    arguments["-c"]="1 set_counters"
    arguments["--counters"]="1 set_counters"
    arguments["-cr"]="1 set_counters_regex"
    arguments["--counters-regex"]="1 set_counters_regex"
    arguments["-f"]="1 set_input_file"
    arguments["--file"]="1 set_input_file"
    arguments["-o"]="1 set_output_file"
    arguments["--output"]="1 set_output_file"
    arguments["-h"]="0 print_help"
    arguments["--help"]="0 print_help"
    arguments["-v"]="0 print_version"
    arguments["--version"]="0 print_version"


    local idx=1
    local failed=0

    while [ $idx -le "$#" ]; do
        local arg=${!idx}
        idx=$((idx+1))

        if [[ -v arguments[$arg] ]]; then
            local invocation_info="${arguments[$arg]}"
            local args="${invocation_info%% *}"
            local fn="${invocation_info##* }"

            local upper_idx=$((idx+args-1))

            if [[ $upper_idx -gt "$#" ]]; then
                >&2 echo "Error: not enough arguments for $arg"
                failed=1
            else
                $fn ${@:idx:args}

                if [[ $? -ne 0 ]]; then
                    failed=1
                fi

                idx=$((idx+args))
            fi
        fi
    done

    return $failed
}

function initialize_defaults() {
    if [[ -z ${classify+x} ]]; then
        classify=$default_classify
    fi

    if [[ -z ${index+x} ]]; then
        index=$default_index
    fi

    if [[ -z ${counters+x} ]]; then
        counters=$default_counters
    fi

    if [[ -z ${output_file+x} ]]; then
        output_file="sar-job"
    fi

    if [[ -z ${input_file+x} ]]; then
        input_file="/dev/stdin"
    fi
}

declare -A jobs
declare -A groups

function append_array() {
    if [[ ! -v jobs[$1,length] ]]; then
        jobs[$1,length]=0
    fi

    length=${jobs[$1,length]}

    jobs[$1,$length]=$2
    jobs[$1,length]=$((length+1))
}

function group_jobs() {
    while read line
    do
        no_comma=$(echo $line | sed 's/,//')

        file=$(echo $no_comma | head -n1 | awk '{ print $1; }')
        gps=$(echo $no_comma | head -n1 | awk '{ print $2; }')
        class=$(do_classify $file)

        groups[$gps-$class]="$gps"
        append_array "$gps-$class" $file
    done <<< "$(cat $input_file)"
}

function find_gaps_and_duplicates() {
    expected=0
    echo "$1"
}

function sort_jobs() {
    length=${jobs[$1,length]}

    ordered=$(for idx in $(seq 0 $length)
    do
        value=${jobs[$1,$idx]}
        number=$(do_index $value)

        if [[ -z $number ]]; then
            &>2 echo "Error: could not compute index of $value"
        fi

        counter_file=$(do_counters $value)

        if [[ ! -f $counter_file ]]; then
            &>2 echo "Error: counter file \"$counter_file\" for $value not found"
        fi

        echo "${number} {'${value}', '${counter_file}'}"
    done | sort -n | awk '{$1= ""; print $0}' | sed '1n; $n; s/$/,/')

    #index_sequence=$(echo $ordered | awk '{ print $1; }')
    #output=$(echo $ordered | awk '{$1= ""; print $0}' | sed '1n; $n; s/$/,/')
    #echo id $index_sequence id
 
    #echo op $output op
 
    #find_gaps_and_duplicates "$ordered"

    echo ${groups[$1]} > "${output_file}-$(basename $1).txt"
    echo "${ordered:5}" >> "${output_file}-$(basename $1).txt"
}

parse_command_line "${@:1}"
failed=$?
if [[ $failed -ne 0 ]]; then
    &>2 echo "Error: failed to parse command line"
    exit 1
fi

initialize_defaults
group_jobs

for job in "${!groups[@]}"
do
    sort_jobs $job
done
