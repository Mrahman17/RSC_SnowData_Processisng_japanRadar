% Given a list of counter files, and a mode index, this function computes
% the total number of columns in the file.
function length = count_total_columns(file_list, mode)
    length = 0;

    for i = 1:size(file_list, 1)
        length = length + count_matrix_columns(file_list(i), mode);
    end
end
