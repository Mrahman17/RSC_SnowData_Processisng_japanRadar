%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%               Array Processing (Phase and Amplitude Correction only)%%%
%%%                                                                     %%%
%%%                                                                     %%%    
%%%                           M. Mahbubur Rahman                        %%%
%%%                           Harika Ancha (summer Intern 2019)         %%%
%%%                          The University of Alabama                  %%%
%%%                           Remote Sensing Center                     %%% 
%%%                               Date: 6/22/19                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Inputs:
% arr: Cell array that contains all the sar processed data from all the channels
% ref_channel: reference channel number 
% radar_param: parameter structure containig radar parameters
% Depth1: starting range value to search for a spetecular return
% Depth2:ending range value to search for a spetecular return
%Outputs:
% multi_ch_data: all the sar processed echograms are added after phase and
% amplitude correction
% Range: range vector 
% st_idx: slow-time index of spectecular range line

function [multi_ch_data,range,st_idx] = Phase_Amp_comp(arr,ref_channel,num_channel,radar_param,depth1,depth2)
        
        % set axis of plotting
        ref_sardata=arr{ref_channel};
        M1 =size(ref_sardata,1);
        fc=radar_param.fc;
        fs=radar_param.fs;
        dt=1/fs; %due to complex sampling; sampling at 500 MHz I/Q
        ft=0:dt:(M1-1)*dt;
        c=3e8;
        c_ice=c/sqrt(3.15);
        
        % 0.212e-6 is the surface time
        range=(ft-0.212e-6)*c_ice/2; % Range axis;
        
        % find the most spectecular rangeline peak within bottom layer in ref_channel
       
        del_r=range(2)-range(1);
        
        depth1_idx=min(find(range < depth1+2*del_r & range >depth1 ));
        depth2_idx=min(find(range < depth2+2*del_r & range >depth2 ));
        
        ref_sardata=arr{ref_channel};
        [ft_idx,st_idx]=spec_rangeline(ref_sardata,depth1_idx,depth2_idx);
        
        % Frequency axis
        
        
        T=M1*dt;
        df=1/T;
        freq=fc+[-floor(M1/2)*df:df:(ceil(M1/2) -1)*df].';
        
        
        % Find Phase and  Amp for all the channels
        for channel=1:num_channel
                srdata=arr{channel};
                Amp(channel)=abs(srdata(ft_idx,st_idx));
                Ph(channel)=angle(srdata(ft_idx,st_idx));
        end
        
        % calculate reference channel's Amp and Phase
        ref_Amp =Amp(ref_channel);
        ref_Ph =Ph(ref_channel);
        
        
        % find Amp and Phase with respect to reference channel for other channels
        
        Ph_data=Ph-ref_Ph;
        Amp_diff=Amp-ref_Amp;
        
        
        % Calculate expected Phase by using interpolation
        % Create a phase vector with starting and ending channel's phase when first
        % channel is the reference channel.
        % Otherwise use 3 elements to create your initial phase vector
        % This Phase_vector will be populated according to the number of channels
        
        if ref_channel== 1
                phase_vector= [ref_Ph, Ph(end)];
        else
                phase_vector= [Ph(1) ref_Ph, Ph(end)];
        end
        
        expected_phase= interp1(linspace(1,num_channel,length(phase_vector)),phase_vector,linspace(1,num_channel,num_channel));
        
        
        
        %Phase error= Expected Phase-Phase_data;
        
        Phase_error = expected_phase-Ph_data;
        mean_phase_error = (sum(Phase_error))/num_channel-1;
        
%         % Apply Phase Compensation and Amplitude compensation to reference channel and
%         % plot the A-scope
%         
%            sdata=ifft(fft(ref_sardata).*exp((-1j*freq*mean_phase_error)/fc));
%            sdata=(abs(sdata))*mean(Amp_diff);
%         
%         % PLOT A-scope for Reference Channel
%            figure(122); plot(range,20*log10(abs(sdata(:,st_idx))));grid on;
%            title('A-Scope for Reference Channel'); xlabel('Range (m)'); ylabel('Amplitude (dB)')
%            clear sdata;
%         
        multi_ch_data=zeros (size(arr{1}));
        for channel=1:num_channel
                sar_data1=ifft(fft(arr{channel}).*exp((-1j*freq*mean_phase_error)/fc));
                sar_data1=(abs(sar_data1))*mean(Amp_diff);
                multi_ch_data= multi_ch_data+ sar_data1;
                clear sar_data1;
        end
%         figure(149); plot(range,20*log10(abs(multi_ch_data(:,st_idx))));grid on; 
%         title('A-Scope after combining 4 Channels'); 
%         xlabel('Range (m)'); ylabel('Amplitude (dB)')


end

